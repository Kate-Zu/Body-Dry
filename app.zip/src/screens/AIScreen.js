import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../constants/colors';
import { Card } from '../components';
import { useTranslation } from '../i18n';

const AICard = ({ title, description, actionText, onPress }) => (
  <TouchableOpacity onPress={onPress}>
    <Card style={styles.aiCard}>
      <Text style={styles.aiCardTitle}>{title}</Text>
      <View style={styles.aiCardContent}>
        <View style={styles.aiCardIcon}>
          <Ionicons name="sparkles" size={40} color={Colors.primary} />
        </View>
        <View style={styles.aiCardText}>
          <Text style={styles.aiCardDescription}>{description}</Text>
          <View style={styles.aiCardAction}>
            <Text style={styles.aiCardActionText}>{actionText}</Text>
            <Ionicons name="arrow-forward" size={20} color={Colors.white} />
          </View>
        </View>
      </View>
    </Card>
  </TouchableOpacity>
);

export const AIScreen = ({ navigation }) => {
  const { t } = useTranslation();
  
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{t('ai.assistant').toUpperCase()}</Text>
        <View style={styles.aiAvatar}>
          <Text style={styles.aiAvatarText}>AI</Text>
        </View>
      </View>

      <View style={styles.content}>
        <AICard
          title={t('ai.dryPlanTitle')}
          description={t('ai.dryPlanDescription')}
          actionText={t('ai.tapToView')}
          onPress={() => navigation.navigate('AIDryPlan')}
        />

        <AICard
          title={t('ai.recipesTitle')}
          description={t('ai.recipesDescription')}
          actionText={t('ai.tapToView')}
          onPress={() => navigation.navigate('AIRecipes')}
        />

        <AICard
          title={t('ai.progressAnalysisTitle')}
          description={t('ai.progressAnalysisDescription')}
          actionText={t('ai.tapToView')}
          onPress={() => {}}
        />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 25,
    paddingVertical: 20,
    marginTop: 30,
  },
  title: {
    fontSize: 20,
    fontWeight: '500',
    color: Colors.white,
    textTransform: 'uppercase',
  },
  aiAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  aiAvatarText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.dark,
  },
  content: {
    flex: 1,
    paddingHorizontal: 25,
    gap: 15,
  },
  aiCard: {
    padding: 15,
  },
  aiCardTitle: {
    fontSize: 18,
    fontWeight: '500',
    color: Colors.primary,
    textAlign: 'center',
    marginBottom: 15,
  },
  aiCardContent: {
    flexDirection: 'row',
    gap: 15,
    alignItems: 'center',
  },
  aiCardIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(187, 224, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  aiCardText: {
    flex: 1,
    gap: 10,
  },
  aiCardDescription: {
    fontSize: 12,
    color: Colors.white,
    lineHeight: 16,
  },
  aiCardAction: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  aiCardActionText: {
    fontSize: 10,
    color: Colors.textSecondary,
  },
});
