import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../constants/colors';
import { ProgressRing } from '../components';
import { useDiaryStore } from '../store';
import { useTranslation } from '../i18n';

export const WaterTrackerScreen = ({ navigation }) => {
  const { t } = useTranslation();
  const { dayData, addWater, updateWaterOptimistic } = useDiaryStore();
  const [stepAmount, setStepAmount] = useState(0.25);
  const [localWater, setLocalWater] = useState(0);
  const pendingAmount = useRef(0);
  const debounceTimer = useRef(null);

  const waterGoal = dayData?.water?.goal || 2;
  const waterConsumed = dayData?.water?.current || 0;

  useEffect(() => {
    setLocalWater(waterConsumed);
  }, [waterConsumed]);

  // Очистка таймера при розмонтуванні
  useEffect(() => {
    return () => {
      if (debounceTimer.current) {
        clearTimeout(debounceTimer.current);
        // Відправляємо накопичене значення перед закриттям
        if (pendingAmount.current !== 0) {
          addWater(pendingAmount.current);
        }
      }
    };
  }, [addWater]);

  const waterProgress = (localWater / waterGoal) * 100;

  // Debounced відправка на сервер - накопичуємо зміни та відправляємо разом
  const debouncedSave = useCallback((amount) => {
    pendingAmount.current += amount;
    
    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }
    
    debounceTimer.current = setTimeout(() => {
      if (pendingAmount.current !== 0) {
        addWater(pendingAmount.current);
        pendingAmount.current = 0;
      }
    }, 500); // Чекаємо 500мс перед відправкою
  }, [addWater]);

  // Миттєве оновлення при натисканні + та -
  const handleAdd = useCallback(() => {
    const newValue = localWater + stepAmount;
    setLocalWater(newValue);
    // Оптимістичне оновлення UI на головній сторінці
    updateWaterOptimistic(newValue);
    // Накопичуємо та відправляємо з debounce
    debouncedSave(stepAmount);
  }, [localWater, stepAmount, updateWaterOptimistic, debouncedSave]);

  const handleRemove = useCallback(() => {
    const newValue = Math.max(localWater - stepAmount, 0);
    setLocalWater(newValue);
    updateWaterOptimistic(newValue);
    debouncedSave(-stepAmount);
  }, [localWater, stepAmount, updateWaterOptimistic, debouncedSave]);

  // Кнопка "назад" - просто повертаємось, дані вже збережені
  const handleBack = () => {
    navigation.goBack();
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={handleBack}>
          <Ionicons name="chevron-back" size={24} color={Colors.white} />
        </TouchableOpacity>
        <Text style={styles.title}>{t('water.tracker')}</Text>
        <View style={{ width: 28 }} />
      </View>

      <View style={styles.content}>
        <View style={styles.waterInfo}>
          <Text style={styles.waterLabel}>{t('water.todayConsumption')}</Text>
          <Text style={styles.waterAmount}>
            {localWater.toFixed(1)} {t('water.liters')} / {waterGoal} {t('water.liters')}
          </Text>
        </View>

        <View style={styles.progressContainer}>
          <ProgressRing
            progress={Math.min(waterProgress, 100)}
            size={280}
            strokeWidth={40}
            color={Colors.primary}
            bgColor="rgba(187, 224, 255, 0.1)"
          />
        </View>

        <View style={styles.stepperSection}>
          <View style={styles.stepper}>
            <TouchableOpacity
              style={[styles.stepperButton, localWater <= 0 && styles.stepperButtonDisabled]}
              onPress={handleRemove}
              disabled={localWater <= 0}
            >
              <Ionicons name="remove" size={24} color={Colors.white} />
            </TouchableOpacity>

            <Text style={styles.stepperValue}>{stepAmount.toFixed(2)} L</Text>

            <TouchableOpacity
              style={styles.stepperButton}
              onPress={handleAdd}
            >
              <Ionicons name="add" size={24} color={Colors.white} />
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.stepOptions}>
          {[0.1, 0.25, 0.5].map((amount) => (
            <TouchableOpacity
              key={amount}
              style={[
                styles.stepOption,
                stepAmount === amount && styles.stepOptionActive,
              ]}
              onPress={() => setStepAmount(amount)}
            >
              <Text
                style={[
                  styles.stepOptionText,
                  stepAmount === amount && styles.stepOptionTextActive,
                ]}
              >
                {amount} L
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.hintText}>
          {t('water.swipeHint')}
        </Text>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 15,
    marginTop: 20,
  },
  backButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: 'rgba(244, 244, 244, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 18,
    fontWeight: '500',
    color: Colors.white,
    textTransform: 'uppercase',
  },
  content: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  waterInfo: {
    alignItems: 'center',
    marginTop: 30,
    marginBottom: 30,
  },
  waterLabel: {
    fontSize: 16,
    color: Colors.textSecondary,
    marginBottom: 10,
  },
  waterAmount: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.white,
  },
  progressContainer: {
    marginBottom: 40,
  },
  stepperSection: {
    width: '100%',
    marginBottom: 30,
  },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 30,
  },
  stepperButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(242, 242, 247, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  stepperButtonDisabled: {
    opacity: 0.3,
  },
  stepperValue: {
    fontSize: 34,
    fontWeight: '700',
    color: Colors.white,
    minWidth: 100,
    textAlign: 'center',
  },
  stepOptions: {
    flexDirection: 'row',
    gap: 15,
    marginBottom: 20,
  },
  stepOption: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
    backgroundColor: 'rgba(242, 242, 247, 0.1)',
  },
  stepOptionActive: {
    backgroundColor: Colors.primary,
  },
  stepOptionText: {
    fontSize: 14,
    color: Colors.white,
    fontWeight: '500',
  },
  stepOptionTextActive: {
    color: Colors.dark,
  },
  hintText: {
    fontSize: 11,
    color: '#7D7D7D',
    textAlign: 'center',
  },
});
