import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/colors';
import { useAuthStore } from '../../store';
import { useTranslation } from '../../i18n';

export const MacroCaloriesEditScreen = ({ navigation }) => {
  const { t } = useTranslation();
  const { user, updateGoals, isSubmitting, fetchProfile } = useAuthStore();
  const profile = user?.profile;
  
  // Initialize from profile data
  const [calories, setCalories] = useState('');
  const [protein, setProtein] = useState('');
  const [carbs, setCarbs] = useState('');
  const [fats, setFats] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // Load profile data on mount
  useEffect(() => {
    const loadData = async () => {
      await fetchProfile();
      setIsLoading(false);
    };
    loadData();
  }, []);

  // Update state when profile loads
  useEffect(() => {
    if (profile) {
      setCalories(String(profile.calorieGoal || 2100));
      setProtein(String(profile.proteinGoal || 120));
      setCarbs(String(profile.carbsGoal || 250));
      setFats(String(profile.fatsGoal || 60));
    }
  }, [profile]);

  // Calculate percentages
  const totalGrams = (parseInt(protein) || 0) + (parseInt(carbs) || 0) + (parseInt(fats) || 0);
  const proteinPercent = totalGrams > 0 ? Math.round((parseInt(protein) || 0) / totalGrams * 100) : 0;
  const carbsPercent = totalGrams > 0 ? Math.round((parseInt(carbs) || 0) / totalGrams * 100) : 0;
  const fatsPercent = totalGrams > 0 ? Math.round((parseInt(fats) || 0) / totalGrams * 100) : 0;

  const handleSave = async () => {
    const calorieVal = parseInt(calories);
    const proteinVal = parseInt(protein);
    const carbsVal = parseInt(carbs);
    const fatsVal = parseInt(fats);

    // Validation
    if (isNaN(calorieVal) || calorieVal < 800 || calorieVal > 10000) {
      Alert.alert(t('common.error'), t('macroEdit.caloriesRange'));
      return;
    }
    if (isNaN(proteinVal) || proteinVal < 20 || proteinVal > 500) {
      Alert.alert(t('common.error'), t('macroEdit.proteinRange'));
      return;
    }
    if (isNaN(carbsVal) || carbsVal < 20 || carbsVal > 800) {
      Alert.alert(t('common.error'), t('macroEdit.carbsRange'));
      return;
    }
    if (isNaN(fatsVal) || fatsVal < 20 || fatsVal > 300) {
      Alert.alert(t('common.error'), t('macroEdit.fatsRange'));
      return;
    }

    const success = await updateGoals({
      calorieGoal: calorieVal,
      proteinGoal: proteinVal,
      carbsGoal: carbsVal,
      fatsGoal: fatsVal,
    });

    if (success) {
      Alert.alert(t('common.success'), t('macroEdit.goalsSaved'));
      navigation.goBack();
    } else {
      Alert.alert(t('common.error'), t('macroEdit.saveError'));
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
            <Ionicons name="chevron-back" size={24} color={Colors.white} />
          </TouchableOpacity>
          <Text style={styles.title}>{t('common.edit').toUpperCase()}</Text>
          <View style={{ width: 42 }} />
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  const MacroRow = ({ label, value, grams, percent, color, onChangeText }) => (
    <>
      <View style={styles.macroItem}>
        <View style={styles.macroLabel}>
          <View style={[styles.macroIndicator, { backgroundColor: color }]} />
          <Text style={styles.macroLabelText}>{label}</Text>
          <Text style={styles.macroGrams}>{grams} {t('units.g')}</Text>
        </View>
        <View style={styles.macroRight}>
          <TextInput
            style={styles.inputValue}
            value={value}
            onChangeText={onChangeText}
            keyboardType="number-pad"
          />
          <Text style={styles.macroPercent}>{percent}%</Text>
        </View>
      </View>
      <View style={styles.divider} />
    </>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={24} color={Colors.white} />
        </TouchableOpacity>
        <Text style={styles.title}>{t('common.edit').toUpperCase()}</Text>
        <TouchableOpacity 
          style={styles.confirmButton} 
          onPress={handleSave}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <ActivityIndicator size="small" color="#BBE0FF" />
          ) : (
            <Ionicons name="checkmark" size={28} color="#BBE0FF" />
          )}
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <Text style={styles.sectionTitle}>{t('goalsScreen.dailyGoals')}</Text>

        {/* Calories */}
        <View style={styles.caloriesRow}>
          <Text style={styles.caloriesLabel}>{t('diary.calories')}</Text>
          <TextInput
            style={styles.caloriesInput}
            value={calories}
            onChangeText={setCalories}
            keyboardType="number-pad"
          />
        </View>
        <View style={styles.divider} />

        {/* Macros */}
        <MacroRow
          label={t('diary.protein')}
          value={protein}
          grams={protein}
          percent={proteinPercent}
          color="#FFAD8F"
          onChangeText={setProtein}
        />
        
        <MacroRow
          label={t('diary.carbs')}
          value={carbs}
          grams={carbs}
          percent={carbsPercent}
          color="#BBE0FF"
          onChangeText={setCarbs}
        />
        
        <MacroRow
          label={t('diary.fats')}
          value={fats}
          grams={fats}
          percent={fatsPercent}
          color="#FEFFFC"
          onChangeText={setFats}
        />

        {/* Percentages Summary */}
        <View style={styles.percentSummary}>
          <View style={styles.percentBar}>
            <View style={[styles.percentSegment, { flex: proteinPercent || 1, backgroundColor: '#FFAD8F' }]} />
            <View style={[styles.percentSegment, { flex: carbsPercent || 1, backgroundColor: '#BBE0FF' }]} />
            <View style={[styles.percentSegment, { flex: fatsPercent || 1, backgroundColor: '#FEFFFC' }]} />
          </View>
          <Text style={styles.percentTotal}>
            {proteinPercent + carbsPercent + fatsPercent}% всього
          </Text>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 22,
    paddingVertical: 15,
  },
  backButton: {
    width: 42,
    height: 42,
    backgroundColor: 'rgba(244,244,244,0.1)',
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 18,
    fontWeight: '500',
    color: Colors.white,
    textTransform: 'uppercase',
  },
  confirmButton: {
    width: 42,
    height: 42,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
    paddingHorizontal: 23,
    paddingTop: 50,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.white,
    textAlign: 'center',
    marginBottom: 30,
  },
  caloriesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 40,
  },
  caloriesLabel: {
    fontSize: 12,
    fontWeight: '500',
    color: Colors.white,
  },
  caloriesInput: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.white,
    backgroundColor: 'transparent',
    textAlign: 'right',
    minWidth: 80,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  divider: {
    height: 0.5,
    backgroundColor: '#A8A8A8',
  },
  macroItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 40,
  },
  macroLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  macroIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  macroLabelText: {
    fontSize: 12,
    fontWeight: '500',
    color: Colors.white,
  },
  macroGrams: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.4)',
  },
  macroRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  inputValue: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.white,
    textAlign: 'right',
    minWidth: 50,
  },
  macroPercent: {
    fontSize: 12,
    fontWeight: '600',
    color: '#BBE0FF',
    minWidth: 35,
    textAlign: 'right',
  },
  percentSummary: {
    marginTop: 30,
    alignItems: 'center',
  },
  percentBar: {
    flexDirection: 'row',
    width: '100%',
    height: 8,
    borderRadius: 4,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  percentSegment: {
    height: '100%',
  },
  percentTotal: {
    marginTop: 10,
    fontSize: 12,
    color: 'rgba(255,255,255,0.6)',
  },
});
