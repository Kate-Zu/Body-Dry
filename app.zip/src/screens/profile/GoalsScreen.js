import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { Colors } from '../../constants/colors';
import { useAuthStore, useProgressStore } from '../../store';
import { useTranslation } from '../../i18n';

// Get activity level label
const getActivityLabel = (t, level) => {
  const map = {
    SEDENTARY: t('activityLevels.sedentary'),
    LIGHT: t('activityLevels.light'),
    MODERATE: t('activityLevels.moderate'),
    ACTIVE: t('activityLevels.active'),
    VERY_ACTIVE: t('activityLevels.veryActive'),
  };
  return map[level] || t('goals.notSpecified');
};

// Get weekly goal label
const getWeeklyGoalLabel = (t, goal) => {
  const map = {
    LOSE_WEIGHT: t('goalsScreen.loseWeekly'),
    DRYING: t('goalsScreen.dryingWeekly'),
    MAINTAIN: t('goals.maintain'),
    GAIN_MUSCLE: t('goalsScreen.gainWeekly'),
  };
  return map[goal] || t('goals.maintain');
};

// Format date to DD.MM.YYYY
const formatDate = (dateString) => {
  if (!dateString) return '-';
  const date = new Date(dateString);
  return `${date.getDate().toString().padStart(2, '0')}.${(date.getMonth() + 1).toString().padStart(2, '0')}.${date.getFullYear()}`;
};

export const GoalsScreen = ({ navigation }) => {
  const { t } = useTranslation();
  const { user, fetchProfile } = useAuthStore();
  const { weightHistory, fetchWeightHistory } = useProgressStore();
  const [isLoading, setIsLoading] = useState(true);
  const profile = user?.profile;

  // Get the latest actual weight from history
  const getLatestWeight = () => {
    if (!weightHistory || !Array.isArray(weightHistory) || weightHistory.length === 0) {
      return profile?.currentWeight || '-';
    }
    // Find the last non-expected entry
    for (let i = weightHistory.length - 1; i >= 0; i--) {
      if (!weightHistory[i].isExpected) {
        return weightHistory[i].weight;
      }
    }
    return profile?.currentWeight || '-';
  };

  // Refresh profile when screen is focused
  useFocusEffect(
    useCallback(() => {
      const loadProfile = async () => {
        setIsLoading(true);
        await Promise.all([fetchProfile(), fetchWeightHistory()]);
        setIsLoading(false);
      };
      loadProfile();
    }, [fetchProfile, fetchWeightHistory])
  );

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
            <Ionicons name="chevron-back" size={24} color={Colors.white} />
          </TouchableOpacity>
          <Text style={styles.title}>{t('goals.title').toUpperCase()}</Text>
          <View style={{ width: 42 }} />
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  const goals = {
    startWeight: profile?.currentWeight || '-',
    startDate: formatDate(profile?.createdAt),
    currentWeight: getLatestWeight(),
    targetWeight: profile?.targetWeight || '-',
    weeklyGoal: getWeeklyGoalLabel(t, profile?.goal),
    lifestyle: getActivityLabel(t, profile?.activityLevel),
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={24} color={Colors.white} />
        </TouchableOpacity>
        <Text style={styles.title}>{t('goals.title').toUpperCase()}</Text>
        <View style={{ width: 42 }} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Weight Section */}
        <View style={styles.weightSection}>
          <View style={styles.weightRow}>
            <Text style={styles.weightLabel}>{t('progress.startWeight')}</Text>
            <Text style={styles.weightValue}>{goals.startWeight} {t('units.kg')}, {goals.startDate}</Text>
          </View>
          <View style={styles.divider} />
          
          <View style={styles.weightRow}>
            <Text style={styles.weightLabel}>{t('profile.currentWeight')}</Text>
            <Text style={styles.weightValue}>{goals.currentWeight} {t('units.kg')}</Text>
          </View>
          <View style={styles.divider} />
          
          <View style={styles.weightRow}>
            <Text style={styles.weightLabel}>{t('profile.targetWeight')}</Text>
            <Text style={styles.weightValue}>{goals.targetWeight} {t('units.kg')}</Text>
          </View>
          <View style={styles.divider} />
          
          <View style={styles.weightRow}>
            <Text style={styles.weightLabel}>{t('goalsScreen.weeklyGoal')}</Text>
            <Text style={styles.weightValueHighlight}>{goals.weeklyGoal}</Text>
          </View>
          <View style={styles.divider} />
          
          <View style={styles.weightRow}>
            <Text style={styles.weightLabel}>{t('goalsScreen.lifestyle')}</Text>
            <Text style={styles.weightValueHighlight}>{goals.lifestyle}</Text>
          </View>
        </View>

        {/* Nutrition Goals Section */}
        <View style={styles.nutritionSection}>
          <Text style={styles.sectionTitle}>{t('goalsScreen.nutritionGoals')}</Text>
          
          <TouchableOpacity 
            style={styles.nutritionItem}
            onPress={() => navigation.navigate('MacroCaloriesEdit')}
          >
            <View style={styles.nutritionText}>
              <Text style={styles.nutritionTitle}>
                {t('goalsScreen.macroGoals')}
              </Text>
              <Text style={styles.nutritionDesc}>
                {t('goalsScreen.macroGoalsDesc')}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={Colors.white} />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 22,
    paddingVertical: 15,
  },
  backButton: {
    width: 42,
    height: 42,
    backgroundColor: 'rgba(244,244,244,0.1)',
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: '500',
    color: Colors.white,
    textTransform: 'uppercase',
  },
  content: {
    flex: 1,
    paddingHorizontal: 22,
  },
  weightSection: {
    marginBottom: 30,
  },
  weightRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 40,
  },
  weightLabel: {
    fontSize: 12,
    fontWeight: '500',
    color: 'rgba(255, 255, 255, 0.6)',
  },
  weightValue: {
    fontSize: 12,
    fontWeight: '500',
    color: Colors.white,
  },
  weightValueHighlight: {
    fontSize: 12,
    fontWeight: '500',
    color: '#BBE0FF',
  },
  divider: {
    height: 0.5,
    backgroundColor: 'rgba(255, 255, 255, 0.6)',
  },
  nutritionSection: {
    gap: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '500',
    color: Colors.white,
  },
  nutritionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 15,
  },
  nutritionText: {
    flex: 1,
    marginRight: 10,
  },
  nutritionTitle: {
    fontSize: 12,
    fontWeight: '500',
    color: Colors.white,
    marginBottom: 5,
  },
  nutritionDesc: {
    fontSize: 10,
    color: 'rgba(255, 255, 255, 0.6)',
  },
});
