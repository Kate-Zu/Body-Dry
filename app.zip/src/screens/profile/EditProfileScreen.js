import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/colors';
import { useAuthStore } from '../../store/authStore';
import { useTranslation } from '../../i18n';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Platform } from 'react-native';

const ACTIVITY_LEVELS = [
  { value: 'SEDENTARY', labelKey: 'activityLevels.sedentary' },
  { value: 'LIGHT', labelKey: 'activityLevels.light' },
  { value: 'MODERATE', labelKey: 'activityLevels.moderate' },
  { value: 'ACTIVE', labelKey: 'activityLevels.active' },
  { value: 'VERY_ACTIVE', labelKey: 'activityLevels.veryActive' },
];

const GOALS = [
  { value: 'LOSE_WEIGHT', labelKey: 'goals.loseWeight' },
  { value: 'MAINTAIN', labelKey: 'goals.maintain' },
  { value: 'GAIN_MUSCLE', labelKey: 'goals.gainMuscle' },
  { value: 'DRYING', labelKey: 'goals.drying' },
];

export const EditProfileScreen = ({ navigation }) => {
  const { t } = useTranslation();
  const { user, updateProfile, isSubmitting } = useAuthStore();
  const profile = user?.profile;

  const [name, setName] = useState(profile?.name || '');
  const [gender, setGender] = useState(profile?.gender || 'MALE');
  const [birthDate, setBirthDate] = useState(
    profile?.birthDate ? new Date(profile.birthDate) : new Date(2000, 0, 1)
  );
  const [height, setHeight] = useState(profile?.height?.toString() || '');
  const [currentWeight, setCurrentWeight] = useState(profile?.currentWeight?.toString() || '');
  const [targetWeight, setTargetWeight] = useState(profile?.targetWeight?.toString() || '');
  const [activityLevel, setActivityLevel] = useState(profile?.activityLevel || 'MODERATE');
  const [goal, setGoal] = useState(profile?.goal || 'MAINTAIN');
  
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showActivityPicker, setShowActivityPicker] = useState(false);
  const [showGoalPicker, setShowGoalPicker] = useState(false);
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};
    
    if (!name.trim()) {
      newErrors.name = t('errors.requiredField');
    }
    
    const heightNum = parseFloat(height);
    if (!height || isNaN(heightNum) || heightNum < 100 || heightNum > 250) {
      newErrors.height = t('errors.invalidHeight');
    }
    
    const currentWeightNum = parseFloat(currentWeight);
    if (!currentWeight || isNaN(currentWeightNum) || currentWeightNum < 30 || currentWeightNum > 300) {
      newErrors.currentWeight = t('errors.invalidWeight');
    }
    
    if (targetWeight) {
      const targetWeightNum = parseFloat(targetWeight);
      if (isNaN(targetWeightNum) || targetWeightNum < 30 || targetWeightNum > 300) {
        newErrors.targetWeight = t('errors.invalidTargetWeight');
      }
    }
    
    const today = new Date();
    const minDate = new Date(today.getFullYear() - 100, 0, 1);
    const maxDate = new Date(today.getFullYear() - 10, 11, 31);
    if (birthDate < minDate || birthDate > maxDate) {
      newErrors.birthDate = t('errors.invalidBirthDate');
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      return;
    }

    const success = await updateProfile({
      name: name.trim(),
      gender,
      birthDate: birthDate.toISOString(),
      height: parseFloat(height),
      currentWeight: parseFloat(currentWeight),
      targetWeight: targetWeight ? parseFloat(targetWeight) : null,
      activityLevel,
      goal,
    });

    if (success) {
      Alert.alert(t('common.success'), '', [
        { text: t('common.ok'), onPress: () => navigation.goBack() }
      ]);
    } else {
      Alert.alert(t('common.error'), t('errors.serverError'));
    }
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('uk-UA');
  };

  const getActivityLabel = (value) => {
    const level = ACTIVITY_LEVELS.find(l => l.value === value);
    return level ? t(level.labelKey) : value;
  };

  const getGoalLabel = (value) => {
    const g = GOALS.find(item => item.value === value);
    return g ? t(g.labelKey) : value;
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={24} color={Colors.white} />
        </TouchableOpacity>
        <Text style={styles.title}>{t('profile.editProfile')}</Text>
        <TouchableOpacity 
          style={styles.saveButton} 
          onPress={handleSave}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <ActivityIndicator size="small" color={Colors.primary} />
          ) : (
            <Text style={styles.saveButtonText}>{t('common.save')}</Text>
          )}
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Name */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>{t('profile.name')}</Text>
          <TextInput
            style={[styles.input, errors.name && styles.inputError]}
            value={name}
            onChangeText={(text) => {
              setName(text);
              if (errors.name) setErrors(prev => ({ ...prev, name: null }));
            }}
            placeholder={t('profile.name')}
            placeholderTextColor="rgba(255,255,255,0.4)"
          />
          {errors.name && <Text style={styles.errorText}>{errors.name}</Text>}
        </View>

        {/* Gender */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>{t('profile.gender')}</Text>
          <View style={styles.genderButtons}>
            <TouchableOpacity
              style={[styles.genderButton, gender === 'MALE' && styles.genderButtonActive]}
              onPress={() => setGender('MALE')}
            >
              <Ionicons 
                name="male" 
                size={20} 
                color={gender === 'MALE' ? Colors.dark : Colors.white} 
              />
              <Text style={[
                styles.genderButtonText,
                gender === 'MALE' && styles.genderButtonTextActive
              ]}>
                {t('profile.male')}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.genderButton, gender === 'FEMALE' && styles.genderButtonActive]}
              onPress={() => setGender('FEMALE')}
            >
              <Ionicons 
                name="female" 
                size={20} 
                color={gender === 'FEMALE' ? Colors.dark : Colors.white} 
              />
              <Text style={[
                styles.genderButtonText,
                gender === 'FEMALE' && styles.genderButtonTextActive
              ]}>
                {t('profile.female')}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Birth Date */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>{t('profile.birthDate')}</Text>
          <TouchableOpacity 
            style={styles.input}
            onPress={() => setShowDatePicker(true)}
          >
            <Text style={styles.inputText}>{formatDate(birthDate)}</Text>
          </TouchableOpacity>
          {showDatePicker && (
            <DateTimePicker
              value={birthDate}
              mode="date"
              display={Platform.OS === 'ios' ? 'spinner' : 'default'}
              onChange={(event, date) => {
                setShowDatePicker(Platform.OS === 'ios');
                if (date) setBirthDate(date);
              }}
              maximumDate={new Date()}
              minimumDate={new Date(1920, 0, 1)}
            />
          )}
        </View>

        {/* Height & Weight Row */}
        <View style={styles.row}>
          <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
            <Text style={styles.label}>{t('profile.height')} ({t('units.cm')})</Text>
            <TextInput
              style={[styles.input, errors.height && styles.inputError]}
              value={height}
              onChangeText={(text) => {
                setHeight(text);
                if (errors.height) setErrors(prev => ({ ...prev, height: null }));
              }}
              placeholder="175"
              placeholderTextColor="rgba(255,255,255,0.4)"
              keyboardType="decimal-pad"
            />
            {errors.height && <Text style={styles.errorText}>{errors.height}</Text>}
          </View>
          <View style={[styles.inputGroup, { flex: 1, marginLeft: 8 }]}>
            <Text style={styles.label}>{t('profile.currentWeight')} ({t('units.kg')})</Text>
            <TextInput
              style={[styles.input, errors.currentWeight && styles.inputError]}
              value={currentWeight}
              onChangeText={(text) => {
                setCurrentWeight(text);
                if (errors.currentWeight) setErrors(prev => ({ ...prev, currentWeight: null }));
              }}
              placeholder="75"
              placeholderTextColor="rgba(255,255,255,0.4)"
              keyboardType="decimal-pad"
            />
            {errors.currentWeight && <Text style={styles.errorText}>{errors.currentWeight}</Text>}
          </View>
        </View>

        {/* Target Weight */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>{t('profile.targetWeight')} ({t('units.kg')})</Text>
          <TextInput
            style={[styles.input, errors.targetWeight && styles.inputError]}
            value={targetWeight}
            onChangeText={(text) => {
              setTargetWeight(text);
              if (errors.targetWeight) setErrors(prev => ({ ...prev, targetWeight: null }));
            }}
            placeholder="70"
            placeholderTextColor="rgba(255,255,255,0.4)"
            keyboardType="decimal-pad"
          />
          {errors.targetWeight && <Text style={styles.errorText}>{errors.targetWeight}</Text>}
        </View>

        {/* Activity Level */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>{t('profile.activityLevel')}</Text>
          <TouchableOpacity 
            style={styles.input}
            onPress={() => setShowActivityPicker(!showActivityPicker)}
          >
            <Text style={styles.inputText}>{getActivityLabel(activityLevel)}</Text>
            <Ionicons name="chevron-down" size={20} color="rgba(255,255,255,0.6)" />
          </TouchableOpacity>
          {showActivityPicker && (
            <View style={styles.pickerContainer}>
              {ACTIVITY_LEVELS.map((level) => (
                <TouchableOpacity
                  key={level.value}
                  style={[
                    styles.pickerOption,
                    activityLevel === level.value && styles.pickerOptionActive
                  ]}
                  onPress={() => {
                    setActivityLevel(level.value);
                    setShowActivityPicker(false);
                  }}
                >
                  <Text style={[
                    styles.pickerOptionText,
                    activityLevel === level.value && styles.pickerOptionTextActive
                  ]}>
                    {t(level.labelKey)}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>

        {/* Goal */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>{t('profile.goal')}</Text>
          <TouchableOpacity 
            style={styles.input}
            onPress={() => setShowGoalPicker(!showGoalPicker)}
          >
            <Text style={styles.inputText}>{getGoalLabel(goal)}</Text>
            <Ionicons name="chevron-down" size={20} color="rgba(255,255,255,0.6)" />
          </TouchableOpacity>
          {showGoalPicker && (
            <View style={styles.pickerContainer}>
              {GOALS.map((item) => (
                <TouchableOpacity
                  key={item.value}
                  style={[
                    styles.pickerOption,
                    goal === item.value && styles.pickerOptionActive
                  ]}
                  onPress={() => {
                    setGoal(item.value);
                    setShowGoalPicker(false);
                  }}
                >
                  <Text style={[
                    styles.pickerOptionText,
                    goal === item.value && styles.pickerOptionTextActive
                  ]}>
                    {t(item.labelKey)}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  backButton: {
    padding: 8,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.white,
  },
  saveButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  saveButtonText: {
    fontSize: 16,
    color: Colors.primary,
    fontWeight: '600',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.7)',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: Colors.white,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  inputText: {
    fontSize: 16,
    color: Colors.white,
    flex: 1,
  },
  row: {
    flexDirection: 'row',
  },
  genderButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  genderButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  genderButtonActive: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  genderButtonText: {
    fontSize: 16,
    color: Colors.white,
  },
  genderButtonTextActive: {
    color: Colors.dark,
    fontWeight: '600',
  },
  pickerContainer: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    marginTop: 8,
    overflow: 'hidden',
  },
  pickerOption: {
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.05)',
  },
  pickerOptionActive: {
    backgroundColor: 'rgba(187, 224, 255, 0.2)',
  },
  pickerOptionText: {
    fontSize: 15,
    color: Colors.white,
  },
  pickerOptionTextActive: {
    color: Colors.primary,
    fontWeight: '600',
  },
  inputError: {
    borderWidth: 1,
    borderColor: '#FF6B6B',
  },
  errorText: {
    color: '#FF6B6B',
    fontSize: 12,
    marginTop: 4,
  },
});
