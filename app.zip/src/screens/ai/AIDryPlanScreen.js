import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/colors';
import { PremiumGate } from '../../components/PremiumGate';
import { useTranslation } from '../../i18n';

// Mock AI response for dry plan
const MOCK_DRY_PLAN = {
  days: [
    {
      day: 'День 1',
      meals: [
        { name: 'Сніданок', items: ['Вівсянка 150г', 'Банан 1шт', 'Грецькі горіхи 20г'] },
        { name: 'Обід', items: ['Курка гриль 200г', 'Рис 150г', 'Салат овочевий'] },
        { name: 'Вечеря', items: ['Риба на парі 180г', 'Овочі на грилі', 'Оливкова олія 1ст.л.'] },
      ],
      kbju: { k: 1800, b: 140, j: 55, u: 180 },
    },
    {
      day: 'День 2',
      meals: [
        { name: 'Сніданок', items: ['Омлет з 3 яєць', 'Тост цільнозерновий', 'Авокадо 50г'] },
        { name: 'Обід', items: ['Індичка 200г', 'Гречка 150г', 'Огірок, помідор'] },
        { name: 'Вечеря', items: ['Творог 5% 200г', 'Ягоди 100г', 'Мед 1ч.л.'] },
      ],
      kbju: { k: 1750, b: 145, j: 50, u: 165 },
    },
  ],
};

const Message = ({ isUser, text, children, t }) => (
  <View style={[styles.message, isUser && styles.messageUser]}>
    <View style={[styles.avatar, isUser ? styles.avatarUser : styles.avatarAI]}>
      <Text style={styles.avatarText}>{isUser ? t('aiDryPlan.me') : 'AI'}</Text>
    </View>
    <View style={[styles.messageBubble, isUser ? styles.messageBubbleUser : styles.messageBubbleAI]}>
      {text && <Text style={styles.messageText}>{text}</Text>}
      {children}
    </View>
  </View>
);

const MealPlanCard = ({ plan, t }) => (
  <View style={styles.mealPlan}>
    {plan.days.map((day, dayIdx) => (
      <View key={dayIdx} style={styles.dayPlan}>
        <Text style={styles.dayTitle}>{t('aiDryPlan.day')} {dayIdx + 1}</Text>
        {day.meals.map((meal, mealIdx) => (
          <View key={mealIdx} style={styles.meal}>
            <Text style={styles.mealName}>{meal.name}:</Text>
            {meal.items.map((item, itemIdx) => (
              <Text key={itemIdx} style={styles.mealItem}>• {item}</Text>
            ))}
          </View>
        ))}
        <Text style={styles.kbju}>
          {t('aiDryPlan.kbju')}: {day.kbju.k} {t('diary.kcal')} | {t('aiDryPlan.proteinShort')}: {day.kbju.b}{t('units.g')} | {t('aiDryPlan.fatsShort')}: {day.kbju.j}{t('units.g')} | {t('aiDryPlan.carbsShort')}: {day.kbju.u}{t('units.g')}
        </Text>
      </View>
    ))}
  </View>
);

export const AIDryPlanScreen = ({ navigation }) => {
  const { t } = useTranslation();
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollViewRef = useRef(null);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    if (!initialized) {
      setMessages([
        { 
          isUser: false, 
          text: t('aiDryPlan.greeting'),
        },
        {
          isUser: false,
          plan: MOCK_DRY_PLAN,
        }
      ]);
      setInitialized(true);
    }
  }, [t, initialized]);

  const handleSend = () => {
    if (!inputText.trim()) return;

    const userMessage = inputText.trim();
    setInputText('');
    
    setMessages(prev => [...prev, { isUser: true, text: userMessage }]);
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      setIsTyping(false);
      setMessages(prev => [...prev, { 
        isUser: false, 
        text: t('aiDryPlan.responseHint')
      }]);
    }, 1500);
  };

  useEffect(() => {
    scrollViewRef.current?.scrollToEnd({ animated: true });
  }, [messages, isTyping]);

  return (
    <PremiumGate feature={t('ai.dryPlan')}>
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={24} color={Colors.white} />
        </TouchableOpacity>
        <Text style={styles.title}>{t('aiDryPlan.title')}</Text>
        <View style={{ width: 42 }} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.chatContainer}
        keyboardVerticalOffset={90}
      >
        <ScrollView 
          ref={scrollViewRef}
          style={styles.chatContent}
          contentContainerStyle={styles.chatContentInner}
          showsVerticalScrollIndicator={false}
        >
          {messages.map((msg, idx) => (
            <Message key={idx} isUser={msg.isUser} text={msg.text} t={t}>
              {msg.plan && <MealPlanCard plan={msg.plan} t={t} />}
            </Message>
          ))}
          
          {isTyping && (
            <View style={styles.typingIndicator}>
              <View style={[styles.avatar, styles.avatarAI]}>
                <Text style={styles.avatarText}>AI</Text>
              </View>
              <View style={styles.typingDots}>
                <ActivityIndicator size="small" color={Colors.primary} />
                <Text style={styles.typingText}>{t('aiDryPlan.aiTyping')}</Text>
              </View>
            </View>
          )}
        </ScrollView>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder={t('aiDryPlan.messagePlaceholder')}
            placeholderTextColor="rgba(255,255,255,0.4)"
            value={inputText}
            onChangeText={setInputText}
            multiline
            maxLength={500}
          />
          <TouchableOpacity 
            style={[styles.sendButton, !inputText.trim() && styles.sendButtonDisabled]}
            onPress={handleSend}
            disabled={!inputText.trim()}
          >
            <Ionicons name="send" size={20} color={inputText.trim() ? Colors.dark : 'rgba(0,0,0,0.3)'} />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
    </PremiumGate>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 23,
    paddingVertical: 15,
  },
  backButton: {
    width: 42,
    height: 42,
    backgroundColor: 'rgba(244,244,244,0.1)',
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: '500',
    color: Colors.white,
    textTransform: 'uppercase',
  },
  chatContainer: {
    flex: 1,
  },
  chatContent: {
    flex: 1,
    paddingHorizontal: 23,
  },
  chatContentInner: {
    paddingBottom: 20,
    gap: 15,
  },
  message: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
  },
  messageUser: {
    flexDirection: 'row-reverse',
  },
  avatar: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarUser: {
    backgroundColor: '#4A90E2',
  },
  avatarAI: {
    backgroundColor: 'rgba(187, 224, 255, 0.2)',
    borderWidth: 1,
    borderColor: '#BBE0FF',
  },
  avatarText: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.white,
  },
  messageBubble: {
    maxWidth: '80%',
    padding: 12,
    borderRadius: 16,
  },
  messageBubbleUser: {
    backgroundColor: 'rgba(187, 224, 255, 0.15)',
    borderWidth: 1,
    borderColor: 'rgba(187, 224, 255, 0.3)',
  },
  messageBubbleAI: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  messageText: {
    fontSize: 14,
    color: Colors.white,
    lineHeight: 20,
  },
  mealPlan: {
    marginTop: 12,
    gap: 16,
  },
  dayPlan: {
    backgroundColor: 'rgba(187, 224, 255, 0.05)',
    borderRadius: 8,
    padding: 12,
  },
  dayTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#BBE0FF',
    marginBottom: 8,
  },
  meal: {
    marginBottom: 8,
  },
  mealName: {
    fontSize: 13,
    fontWeight: '500',
    color: Colors.white,
    marginBottom: 4,
  },
  mealItem: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.7)',
    marginLeft: 8,
    lineHeight: 18,
  },
  kbju: {
    fontSize: 12,
    color: 'rgba(187, 224, 255, 0.8)',
    marginTop: 8,
    fontWeight: '500',
  },
  typingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  typingDots: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  typingText: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.5)',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 23,
    paddingVertical: 12,
    gap: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  input: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 14,
    color: Colors.white,
    maxHeight: 100,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButtonDisabled: {
    backgroundColor: 'rgba(187, 224, 255, 0.3)',
  },
});
