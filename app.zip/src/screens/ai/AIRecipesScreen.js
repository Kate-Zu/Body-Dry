import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Image,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/colors';
import { PremiumGate } from '../../components/PremiumGate';
import { useTranslation } from '../../i18n';

// Mock recipes
const MOCK_RECIPES = [
  {
    name: 'Курка з овочами на грилі',
    time: '30 хв',
    calories: 320,
    protein: 35,
    ingredients: [
      'Куряча грудка - 200г',
      'Кабачок - 100г',
      'Болгарський перець - 1шт',
      'Оливкова олія - 1 ст.л.',
      'Спеції за смаком',
    ],
    instructions: 'Нарізати курку та овочі. Замаринувати в оливковій олії зі спеціями на 15 хв. Готувати на грилі до готовності.',
  },
  {
    name: 'Протеїновий смузі',
    time: '5 хв',
    calories: 250,
    protein: 25,
    ingredients: [
      'Банан - 1шт',
      'Молоко 1.5% - 200мл',
      'Протеїн - 1 порція',
      'Арахісова паста - 1 ст.л.',
    ],
    instructions: 'Всі інгредієнти збити блендером до однорідної консистенції.',
  },
];

const Message = ({ isUser, text, children, t }) => (
  <View style={[styles.message, isUser && styles.messageUser]}>
    <View style={[styles.avatar, isUser ? styles.avatarUser : styles.avatarAI]}>
      <Text style={styles.avatarText}>{isUser ? t('aiRecipes.me') : 'AI'}</Text>
    </View>
    <View style={[styles.messageBubble, isUser ? styles.messageBubbleUser : styles.messageBubbleAI]}>
      {text && <Text style={styles.messageText}>{text}</Text>}
      {children}
    </View>
  </View>
);

const RecipeCard = ({ recipe, t }) => (
  <View style={styles.recipeCard}>
    <View style={styles.recipeHeader}>
      <Text style={styles.recipeName}>{recipe.name}</Text>
      <View style={styles.recipeStats}>
        <View style={styles.recipeStat}>
          <Ionicons name="time-outline" size={14} color="#BBE0FF" />
          <Text style={styles.recipeStatText}>{recipe.time}</Text>
        </View>
        <View style={styles.recipeStat}>
          <Ionicons name="flame-outline" size={14} color="#FFAD8F" />
          <Text style={styles.recipeStatText}>{recipe.calories} {t('diary.kcal')}</Text>
        </View>
        <View style={styles.recipeStat}>
          <Text style={styles.recipeStatText}>{t('aiRecipes.proteinShort')}: {recipe.protein}{t('units.g')}</Text>
        </View>
      </View>
    </View>
    
    <Text style={styles.sectionLabel}>{t('aiRecipes.ingredients')}:</Text>
    {recipe.ingredients.map((ing, idx) => (
      <Text key={idx} style={styles.ingredientItem}>• {ing}</Text>
    ))}
    
    <Text style={styles.sectionLabel}>{t('aiRecipes.instructions')}:</Text>
    <Text style={styles.instructions}>{recipe.instructions}</Text>
  </View>
);

export const AIRecipesScreen = ({ navigation }) => {
  const { t } = useTranslation();
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollViewRef = useRef(null);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    if (!initialized) {
      setMessages([
        { 
          isUser: false, 
          text: t('aiRecipes.greeting'),
        },
      ]);
      setInitialized(true);
    }
  }, [t, initialized]);

  const handleSend = () => {
    if (!inputText.trim()) return;

    const userMessage = inputText.trim();
    setInputText('');
    
    setMessages(prev => [...prev, { isUser: true, text: userMessage }]);
    setIsTyping(true);

    // Simulate AI response with recipes
    setTimeout(() => {
      setIsTyping(false);
      setMessages(prev => [...prev, { 
        isUser: false, 
        text: t('aiRecipes.recipesFound'),
        recipes: MOCK_RECIPES,
      }]);
    }, 2000);
  };

  useEffect(() => {
    scrollViewRef.current?.scrollToEnd({ animated: true });
  }, [messages, isTyping]);

  return (
    <PremiumGate feature={t('ai.recipes')}>
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={24} color={Colors.white} />
        </TouchableOpacity>
        <Text style={styles.title}>{t('aiRecipes.title')}</Text>
        <View style={{ width: 42 }} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.chatContainer}
        keyboardVerticalOffset={90}
      >
        <ScrollView 
          ref={scrollViewRef}
          style={styles.chatContent}
          contentContainerStyle={styles.chatContentInner}
          showsVerticalScrollIndicator={false}
        >
          {messages.map((msg, idx) => (
            <Message key={idx} isUser={msg.isUser} text={msg.text} t={t}>
              {msg.recipes && (
                <View style={styles.recipesContainer}>
                  {msg.recipes.map((recipe, rIdx) => (
                    <RecipeCard key={rIdx} recipe={recipe} t={t} />
                  ))}
                </View>
              )}
            </Message>
          ))}
          
          {isTyping && (
            <View style={styles.typingIndicator}>
              <View style={[styles.avatar, styles.avatarAI]}>
                <Text style={styles.avatarText}>AI</Text>
              </View>
              <View style={styles.typingDots}>
                <ActivityIndicator size="small" color={Colors.primary} />
                <Text style={styles.typingText}>{t('aiRecipes.searchingRecipes')}</Text>
              </View>
            </View>
          )}
        </ScrollView>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder={t('aiRecipes.searchPlaceholder')}
            placeholderTextColor="rgba(255,255,255,0.4)"
            value={inputText}
            onChangeText={setInputText}
            multiline
            maxLength={500}
          />
          <TouchableOpacity 
            style={[styles.sendButton, !inputText.trim() && styles.sendButtonDisabled]}
            onPress={handleSend}
            disabled={!inputText.trim()}
          >
            <Ionicons name="send" size={20} color={inputText.trim() ? Colors.dark : 'rgba(0,0,0,0.3)'} />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
    </PremiumGate>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 23,
    paddingVertical: 15,
  },
  backButton: {
    width: 42,
    height: 42,
    backgroundColor: 'rgba(244,244,244,0.1)',
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: '500',
    color: Colors.white,
    textTransform: 'uppercase',
  },
  chatContainer: {
    flex: 1,
  },
  chatContent: {
    flex: 1,
    paddingHorizontal: 23,
  },
  chatContentInner: {
    paddingBottom: 20,
    gap: 15,
  },
  message: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
  },
  messageUser: {
    flexDirection: 'row-reverse',
  },
  avatar: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarUser: {
    backgroundColor: '#4A90E2',
  },
  avatarAI: {
    backgroundColor: 'rgba(187, 224, 255, 0.2)',
    borderWidth: 1,
    borderColor: '#BBE0FF',
  },
  avatarText: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.white,
  },
  messageBubble: {
    maxWidth: '80%',
    padding: 12,
    borderRadius: 16,
  },
  messageBubbleUser: {
    backgroundColor: 'rgba(187, 224, 255, 0.15)',
    borderWidth: 1,
    borderColor: 'rgba(187, 224, 255, 0.3)',
  },
  messageBubbleAI: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  messageText: {
    fontSize: 14,
    color: Colors.white,
    lineHeight: 20,
  },
  recipesContainer: {
    marginTop: 12,
    gap: 12,
  },
  recipeCard: {
    backgroundColor: 'rgba(187, 224, 255, 0.1)',
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: 'rgba(187, 224, 255, 0.2)',
  },
  recipeHeader: {
    marginBottom: 12,
  },
  recipeName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#BBE0FF',
    marginBottom: 8,
  },
  recipeStats: {
    flexDirection: 'row',
    gap: 15,
  },
  recipeStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  recipeStatText: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.7)',
  },
  sectionLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.white,
    marginTop: 8,
    marginBottom: 6,
  },
  ingredientItem: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    marginLeft: 8,
    lineHeight: 18,
  },
  instructions: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    lineHeight: 18,
  },
  typingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  typingDots: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  typingText: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.5)',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 23,
    paddingVertical: 12,
    gap: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  input: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 14,
    color: Colors.white,
    maxHeight: 100,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButtonDisabled: {
    backgroundColor: 'rgba(187, 224, 255, 0.3)',
  },
});
