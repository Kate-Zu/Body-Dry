import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Image,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '../constants/colors';
import { Button } from '../components';

const { width, height } = Dimensions.get('window');

export const WelcomeScreen = ({ navigation }) => {
  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['rgba(6, 6, 3, 0.1)', 'rgba(6, 6, 3, 0.9)', Colors.background]}
        style={styles.gradient}
      >
        <View style={styles.content}>
          <View style={styles.logoContainer}>
            <View style={styles.logoIcon}>
              <Text style={styles.logoB}>B</Text>
            </View>
            <Text style={styles.logoText}>Body&Dry</Text>
          </View>

          <View style={styles.bottomContent}>
            <View style={styles.textContainer}>
              <Text style={styles.title}>Твоя персональна</Text>
              <Text style={styles.titleHighlight}>AI Plan сушки</Text>
            </View>

            <View style={styles.buttons}>
              <Button
                title="Увійти"
                onPress={() => navigation.navigate('Login')}
              />
              <Button
                title="Зареєструватися"
                variant="secondary"
                onPress={() => navigation.navigate('SignUp')}
                style={styles.signupButton}
              />
            </View>
          </View>
        </View>
      </LinearGradient>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  gradient: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'space-between',
    padding: 30,
    paddingTop: 60,
    paddingBottom: 50,
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  logoIcon: {
    width: 35,
    height: 35,
    backgroundColor: Colors.primary,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoB: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.background,
  },
  logoText: {
    fontSize: 25,
    fontWeight: '500',
    color: Colors.primary,
  },
  bottomContent: {
    gap: 40,
  },
  textContainer: {
    gap: 5,
  },
  title: {
    fontSize: 30,
    fontWeight: '500',
    color: Colors.white,
  },
  titleHighlight: {
    fontSize: 30,
    fontWeight: '600',
    color: Colors.primary,
  },
  buttons: {
    gap: 15,
  },
  signupButton: {
    borderColor: Colors.primary,
  },
});
