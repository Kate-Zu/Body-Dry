import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import Svg, { Path, Circle, Line, Defs, LinearGradient, Stop, Text as SvgText } from 'react-native-svg';
import { Colors } from '../constants/colors';
import { Card } from '../components';
import { useProgressStore, useAuthStore } from '../store';
import { useTranslation } from '../i18n';

const { width } = Dimensions.get('window');
const CHART_WIDTH = width - 72;
const CHART_HEIGHT = 180;
const CHART_PADDING = { top: 20, right: 15, bottom: 30, left: 40 };

export const ProgressScreen = ({ navigation }) => {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('day');
  const { user } = useAuthStore();
  const { 
    weeklyStats, 
    monthlyStats, 
    yearlyStats, 
    weightHistory,
    isLoading,
    fetchWeeklyStats,
    fetchMonthlyStats,
    fetchYearlyStats,
    fetchWeightHistory,
  } = useProgressStore();

  // Refresh when screen is focused
  useFocusEffect(
    useCallback(() => {
      fetchWeeklyStats();
      fetchWeightHistory(30);
    }, [])
  );

  useEffect(() => {
    const limitMap = { day: 1, week: 7, month: 30 };
    fetchWeightHistory(limitMap[activeTab]);
    
    if (activeTab === 'day' || activeTab === 'week') {
      fetchWeeklyStats();
    } else if (activeTab === 'month') {
      fetchMonthlyStats();
    }
  }, [activeTab]);

  const currentStats = activeTab === 'day'
    ? weeklyStats
    : activeTab === 'month' 
      ? monthlyStats 
      : weeklyStats;

  // Helper to get averages from current stats
  const getAverages = () => {
    if (!currentStats?.averages) {
      return { calories: 0, protein: 0, carbs: 0, fats: 0, water: 0 };
    }
    return currentStats.averages;
  };

  // Helper to get goals from current stats
  const getGoals = () => {
    if (!currentStats?.goals) {
      return { calories: 2000, protein: 150, carbs: 200, fats: 70, water: 2500 };
    }
    return currentStats.goals;
  };

  // Helper to get daily data for charts
  const getDailyData = () => {
    if (!currentStats?.dailyData) return [];
    return currentStats.dailyData;
  };

  const averages = getAverages();
  const goals = getGoals();

  // Get weight data for selected period
  const getWeightDataForPeriod = () => {
    if (!weightHistory || !Array.isArray(weightHistory) || weightHistory.length === 0) {
      return [];
    }
    const limitMap = { day: 1, week: 7, month: 30 };
    return weightHistory.slice(-limitMap[activeTab]);
  };

  const weightData = getWeightDataForPeriod();
  
  // Calculate weight stats
  const weights = weightData.filter(w => !w.isExpected).map(w => w.weight);
  const currentWeight = weights.length > 0 ? weights[weights.length - 1] : (user?.profile?.currentWeight || 0);
  const avgWeight = weights.length > 0 ? weights.reduce((a, b) => a + b, 0) / weights.length : 0;
  const minWeight = weights.length > 0 ? Math.min(...weights) : 0;
  const maxWeight = weights.length > 0 ? Math.max(...weights) : 0;
  const weightChange = weights.length >= 2 ? weights[weights.length - 1] - weights[0] : 0;

  // Generate SVG weight chart
  const renderWeightChart = () => {
    if (weightData.length === 0) {
      return (
        <View style={styles.chartEmpty}>
          <Text style={styles.chartEmptyText}>{t('progress.noData')}</Text>
        </View>
      );
    }

    const chartInnerWidth = CHART_WIDTH - CHART_PADDING.left - CHART_PADDING.right;
    const chartInnerHeight = CHART_HEIGHT - CHART_PADDING.top - CHART_PADDING.bottom;

    // Calculate Y axis bounds
    const allWeights = weightData.map(w => w.weight);
    const dataMin = Math.min(...allWeights);
    const dataMax = Math.max(...allWeights);
    const range = dataMax - dataMin || 2;
    const yMin = dataMin - range * 0.15;
    const yMax = dataMax + range * 0.15;

    // Generate points
    const points = weightData.map((entry, index) => {
      const x = CHART_PADDING.left + (index / Math.max(weightData.length - 1, 1)) * chartInnerWidth;
      const y = CHART_PADDING.top + (1 - (entry.weight - yMin) / (yMax - yMin)) * chartInnerHeight;
      return { x, y, weight: entry.weight, date: entry.date, isExpected: entry.isExpected };
    });

    // Smooth bezier curve
    const createSmoothPath = (pts) => {
      if (pts.length < 2) return '';
      let path = `M ${pts[0].x} ${pts[0].y}`;
      for (let i = 0; i < pts.length - 1; i++) {
        const p0 = pts[i === 0 ? i : i - 1];
        const p1 = pts[i];
        const p2 = pts[i + 1];
        const p3 = pts[i + 2 >= pts.length ? i + 1 : i + 2];
        const cp1x = p1.x + (p2.x - p0.x) / 6;
        const cp1y = p1.y + (p2.y - p0.y) / 6;
        const cp2x = p2.x - (p3.x - p1.x) / 6;
        const cp2y = p2.y - (p3.y - p1.y) / 6;
        path += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p2.x} ${p2.y}`;
      }
      return path;
    };

    // Area fill under curve
    const createAreaPath = (pts) => {
      if (pts.length < 2) return '';
      const linePath = createSmoothPath(pts);
      const lastPoint = pts[pts.length - 1];
      const firstPoint = pts[0];
      return `${linePath} L ${lastPoint.x} ${CHART_HEIGHT - CHART_PADDING.bottom} L ${firstPoint.x} ${CHART_HEIGHT - CHART_PADDING.bottom} Z`;
    };

    const realPoints = points.filter(p => !p.isExpected);
    const expectedPoints = points.filter(p => p.isExpected);
    const connectExpected = realPoints.length > 0 && expectedPoints.length > 0 
      ? [realPoints[realPoints.length - 1], ...expectedPoints] 
      : expectedPoints;

    // Y-axis labels
    const yLabels = [yMax, (yMax + yMin) / 2, yMin];

    // X-axis labels
    const getDateLabel = (dateStr, index) => {
      const date = new Date(dateStr);
      if (activeTab === 'year') {
        return date.toLocaleDateString('uk-UA', { month: 'short' }).slice(0, 3);
      }
      if (weightData.length <= 7) {
        return date.toLocaleDateString('uk-UA', { weekday: 'short' }).slice(0, 2);
      }
      if (index % Math.ceil(weightData.length / 7) === 0 || index === weightData.length - 1) {
        return `${date.getDate()}`;
      }
      return '';
    };

    return (
      <Svg width={CHART_WIDTH} height={CHART_HEIGHT}>
        <Defs>
          <LinearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0%" stopColor={Colors.primary} stopOpacity={0.4} />
            <Stop offset="100%" stopColor={Colors.primary} stopOpacity={0.02} />
          </LinearGradient>
        </Defs>

        {/* Grid lines */}
        {yLabels.map((label, i) => {
          const y = CHART_PADDING.top + (i / (yLabels.length - 1)) * chartInnerHeight;
          return (
            <React.Fragment key={i}>
              <Line
                x1={CHART_PADDING.left}
                y1={y}
                x2={CHART_WIDTH - CHART_PADDING.right}
                y2={y}
                stroke="rgba(255,255,255,0.08)"
                strokeWidth={1}
              />
              <SvgText
                x={CHART_PADDING.left - 8}
                y={y + 4}
                fontSize={10}
                fill="rgba(255,255,255,0.4)"
                textAnchor="end"
              >
                {label.toFixed(1)}
              </SvgText>
            </React.Fragment>
          );
        })}

        {/* Area fill */}
        {realPoints.length >= 2 && (
          <Path d={createAreaPath(realPoints)} fill="url(#areaGradient)" />
        )}

        {/* Main line */}
        {realPoints.length >= 2 && (
          <Path
            d={createSmoothPath(realPoints)}
            stroke={Colors.primary}
            strokeWidth={3}
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}

        {/* Expected dashed line */}
        {connectExpected.length >= 2 && (
          <Path
            d={createSmoothPath(connectExpected)}
            stroke={Colors.primary}
            strokeWidth={2}
            strokeOpacity={0.4}
            strokeDasharray="6,4"
            fill="none"
            strokeLinecap="round"
          />
        )}

        {/* Data points */}
        {points.map((point, index) => (
          <Circle
            key={index}
            cx={point.x}
            cy={point.y}
            r={point.isExpected ? 4 : 5}
            fill={point.isExpected ? 'rgba(187,224,255,0.3)' : Colors.white}
            stroke={Colors.primary}
            strokeWidth={2}
          />
        ))}

        {/* X-axis labels */}
        {points.map((point, index) => {
          const label = getDateLabel(point.date, index);
          if (!label) return null;
          return (
            <SvgText
              key={`label-${index}`}
              x={point.x}
              y={CHART_HEIGHT - 8}
              fontSize={10}
              fill="rgba(255,255,255,0.5)"
              textAnchor="middle"
            >
              {label}
            </SvgText>
          );
        })}
      </Svg>
    );
  };

  const getPeriodLabel = () => {
    switch (activeTab) {
      case 'day': return t('progress.day').toLowerCase();
      case 'week': return t('progress.week').toLowerCase();
      case 'month': return t('progress.month').toLowerCase();
      default: return '';
    }
  };

  const tabs = [
    { key: 'day', label: t('progress.day') },
    { key: 'week', label: t('progress.week') },
    { key: 'month', label: t('progress.month') },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.title}>{t('progress.title')}</Text>
        </View>

        {/* Tabs */}
        <View style={styles.tabs}>
          {tabs.map((tab) => (
            <TouchableOpacity
              key={tab.key}
              style={[styles.tab, activeTab === tab.key && styles.tabActive]}
              onPress={() => setActiveTab(tab.key)}
            >
              <Text style={[styles.tabText, activeTab === tab.key && styles.tabTextActive]}>
                {tab.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.content}>
          {isLoading && (
            <View style={styles.loadingOverlay}>
              <ActivityIndicator size="small" color={Colors.primary} />
            </View>
          )}

          {/* Weight Chart Card */}
          <Card style={styles.chartCard}>
            <Text style={styles.chartTitle}>{t('progress.weight')}</Text>
            
            <View style={styles.chartContainer}>
              {renderWeightChart()}
            </View>

            <Text style={styles.weightValue}>
              {currentWeight.toFixed(1)} {t('units.kg')}
            </Text>
            <Text style={[
              styles.weightChange, 
              weightChange > 0 && styles.weightChangeUp,
              weightChange < 0 && styles.weightChangeDown,
            ]}>
              {weightChange > 0 ? '+' : ''}{weightChange.toFixed(1)} {t('units.kg')} {t('progress.for')} {getPeriodLabel()}
            </Text>
          </Card>

          {/* Calories & Goals Card */}
          <Card style={styles.chartCard}>
            <Text style={styles.chartTitle}>{t('progress.nutrition')}</Text>
            
            {/* Calories */}
            <View style={styles.nutritionRow}>
              <View style={styles.nutritionInfo}>
                <Text style={styles.nutritionLabel}>{t('diary.calories')}</Text>
                <Text style={styles.nutritionValue}>
                  {Math.round(averages.calories).toLocaleString()} 
                  <Text style={styles.nutritionGoal}> / {Math.round(goals.calories).toLocaleString()} {t('diary.kcal')}</Text>
                </Text>
              </View>
              <View style={styles.progressBarContainer}>
                <View style={[styles.progressBar, { width: `${Math.min((averages.calories / goals.calories) * 100, 100)}%` }]} />
              </View>
            </View>

            {/* Water */}
            <View style={styles.nutritionRow}>
              <View style={styles.nutritionInfo}>
                <Text style={styles.nutritionLabel}>{t('water.title')}</Text>
                <Text style={styles.nutritionValue}>
                  {(averages.water / 1000).toFixed(1)} 
                  <Text style={styles.nutritionGoal}> / {(goals.water / 1000).toFixed(1)} {t('units.l')}</Text>
                </Text>
              </View>
              <View style={styles.progressBarContainer}>
                <View style={[styles.progressBar, styles.progressBarWater, { width: `${Math.min((averages.water / goals.water) * 100, 100)}%` }]} />
              </View>
            </View>
          </Card>

          {/* Macros Card */}
          <Card style={styles.chartCard}>
            <Text style={styles.chartTitle}>{t('progress.macros')}</Text>
            
            <View style={styles.macrosGrid}>
              {/* Protein */}
              <View style={styles.macroItem}>
                <View style={[styles.macroIcon, { backgroundColor: 'rgba(76, 175, 80, 0.2)' }]}>
                  <Text style={[styles.macroIconText, { color: '#4CAF50' }]}>Б</Text>
                </View>
                <Text style={styles.macroValue}>{Math.round(averages.protein)}{t('units.g')}</Text>
                <Text style={styles.macroGoal}>/ {Math.round(goals.protein)}{t('units.g')}</Text>
                <View style={styles.macroProgressContainer}>
                  <View style={[styles.macroProgress, { width: `${Math.min((averages.protein / goals.protein) * 100, 100)}%`, backgroundColor: '#4CAF50' }]} />
                </View>
              </View>

              {/* Carbs */}
              <View style={styles.macroItem}>
                <View style={[styles.macroIcon, { backgroundColor: 'rgba(255, 193, 7, 0.2)' }]}>
                  <Text style={[styles.macroIconText, { color: '#FFC107' }]}>В</Text>
                </View>
                <Text style={styles.macroValue}>{Math.round(averages.carbs)}{t('units.g')}</Text>
                <Text style={styles.macroGoal}>/ {Math.round(goals.carbs)}{t('units.g')}</Text>
                <View style={styles.macroProgressContainer}>
                  <View style={[styles.macroProgress, { width: `${Math.min((averages.carbs / goals.carbs) * 100, 100)}%`, backgroundColor: '#FFC107' }]} />
                </View>
              </View>

              {/* Fats */}
              <View style={styles.macroItem}>
                <View style={[styles.macroIcon, { backgroundColor: 'rgba(255, 107, 107, 0.2)' }]}>
                  <Text style={[styles.macroIconText, { color: '#FF6B6B' }]}>Ж</Text>
                </View>
                <Text style={styles.macroValue}>{Math.round(averages.fats)}{t('units.g')}</Text>
                <Text style={styles.macroGoal}>/ {Math.round(goals.fats)}{t('units.g')}</Text>
                <View style={styles.macroProgressContainer}>
                  <View style={[styles.macroProgress, { width: `${Math.min((averages.fats / goals.fats) * 100, 100)}%`, backgroundColor: '#FF6B6B' }]} />
                </View>
              </View>
            </View>
          </Card>

          {/* Weight Stats Row */}
          <View style={styles.statsGrid}>
            <Card style={styles.statCard}>
              <Text style={styles.statLabel}>{t('progress.average')}</Text>
              <Text style={styles.statValue}>{avgWeight > 0 ? avgWeight.toFixed(1) : '-'} {t('units.kg')}</Text>
            </Card>
            <Card style={styles.statCard}>
              <Text style={styles.statLabel}>{t('progress.minWeight')}</Text>
              <Text style={styles.statValue}>{minWeight > 0 ? minWeight.toFixed(1) : '-'} {t('units.kg')}</Text>
            </Card>
          </View>

          {/* Calories Bar Chart */}
          <Card style={styles.chartCard}>
            <Text style={styles.chartTitle}>{t('progress.caloriesFor')} {getPeriodLabel()}</Text>
            <View style={styles.barsContainer}>
              {(() => {
                const dailyData = getDailyData();
                
                // For day view, show single value card instead of bars
                if (activeTab === 'day' && dailyData.length > 0) {
                  const todayData = dailyData[dailyData.length - 1];
                  return (
                    <View style={styles.dayValueContainer}>
                      <Text style={styles.dayValueText}>{Math.round(todayData?.calories || 0)}</Text>
                      <Text style={styles.dayValueLabel}>{t('diary.kcal')}</Text>
                    </View>
                  );
                }
                
                // For week - show 7 bars, for month - show sampled data
                const barsToShow = activeTab === 'month' 
                  ? dailyData.filter((_, i) => i % 4 === 0 || i === dailyData.length - 1).slice(-8)
                  : dailyData;
                
                if (barsToShow.length === 0) {
                  return (
                    <View style={styles.chartEmpty}>
                      <Text style={styles.chartEmptyText}>{t('progress.noData')}</Text>
                    </View>
                  );
                }
                
                const maxCal = Math.max(...barsToShow.map(d => d.calories), 1);
                
                return barsToShow.map((item, index) => {
                  const heightPercent = (item.calories / maxCal) * 100;
                  return (
                    <View key={index} style={styles.barItem}>
                      <Text style={styles.barValue}>{Math.round(item.calories / 100) * 100}</Text>
                      <View style={styles.barTrack}>
                        <View style={[styles.bar, { height: `${Math.max(heightPercent, 5)}%` }]} />
                      </View>
                      <Text style={styles.barLabel}>
                        {activeTab === 'month' 
                          ? new Date(item.date).toLocaleDateString('uk-UA', { day: 'numeric' })
                          : new Date(item.date).toLocaleDateString('uk-UA', { weekday: 'short' }).slice(0, 2)
                        }
                      </Text>
                    </View>
                  );
                });
              })()}
            </View>
          </Card>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    paddingBottom: 100,
  },
  header: {
    padding: 20,
    paddingTop: 50,
  },
  title: {
    fontSize: 24,
    fontWeight: '600',
    color: Colors.white,
  },
  tabs: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.15)',
    paddingHorizontal: 20,
    gap: 24,
    marginBottom: 8,
  },
  tab: {
    paddingVertical: 12,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
    marginBottom: -1,
  },
  tabActive: {
    borderBottomColor: Colors.primary,
  },
  tabText: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.textSecondary,
  },
  tabTextActive: {
    color: Colors.primary,
  },
  content: {
    padding: 20,
    gap: 16,
  },
  loadingOverlay: {
    position: 'absolute',
    top: 60,
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 10,
  },
  chartCard: {
    gap: 12,
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.white,
  },
  chartContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 8,
  },
  chartEmpty: {
    height: CHART_HEIGHT,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  chartEmptyText: {
    color: Colors.textSecondary,
    fontSize: 14,
  },
  weightValue: {
    fontSize: 36,
    fontWeight: '700',
    color: Colors.white,
    textAlign: 'center',
    marginTop: 8,
  },
  weightChange: {
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  weightChangeUp: {
    color: '#FF6B6B',
  },
  weightChangeDown: {
    color: '#4CAF50',
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  statCard: {
    flex: 1,
    gap: 8,
  },
  statLabel: {
    fontSize: 13,
    color: Colors.textSecondary,
  },
  statValue: {
    fontSize: 22,
    fontWeight: '600',
    color: Colors.white,
  },
  // Nutrition stats
  nutritionRow: {
    marginBottom: 16,
  },
  nutritionInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  nutritionLabel: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  nutritionValue: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.white,
  },
  nutritionGoal: {
    fontSize: 14,
    fontWeight: '400',
    color: Colors.textSecondary,
  },
  progressBarContainer: {
    height: 8,
    backgroundColor: 'rgba(187, 224, 255, 0.1)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: Colors.primary,
    borderRadius: 4,
  },
  progressBarWater: {
    backgroundColor: '#4FC3F7',
  },
  // Macros
  macrosGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  macroItem: {
    flex: 1,
    alignItems: 'center',
    gap: 6,
  },
  macroIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  macroIconText: {
    fontSize: 18,
    fontWeight: '700',
  },
  macroValue: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.white,
  },
  macroGoal: {
    fontSize: 12,
    color: Colors.textSecondary,
  },
  macroProgressContainer: {
    width: '80%',
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 2,
    overflow: 'hidden',
    marginTop: 4,
  },
  macroProgress: {
    height: '100%',
    borderRadius: 2,
  },
  barsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 160,
    paddingTop: 20,
  },
  dayValueContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    height: 140,
  },
  dayValueText: {
    fontSize: 48,
    fontWeight: '700',
    color: Colors.white,
  },
  dayValueLabel: {
    fontSize: 16,
    color: Colors.textSecondary,
    marginTop: 4,
  },
  barItem: {
    flex: 1,
    alignItems: 'center',
    gap: 6,
  },
  barValue: {
    fontSize: 9,
    color: Colors.textSecondary,
  },
  barTrack: {
    width: 28,
    height: 100,
    backgroundColor: 'rgba(187, 224, 255, 0.08)',
    borderRadius: 6,
    justifyContent: 'flex-end',
    overflow: 'hidden',
  },
  bar: {
    width: '100%',
    backgroundColor: Colors.primary,
    borderRadius: 6,
  },
  barLabel: {
    fontSize: 11,
    color: Colors.textSecondary,
    textTransform: 'capitalize',
  },
});
